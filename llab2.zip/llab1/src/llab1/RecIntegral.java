package llab1;

public class RecIntegral 
{
    double A;
    double B;
    double H;
    double N;
    
    public RecIntegral(double A,double B,double H, double N)
    {
        this.A = A;
        this.B = B;
        this.H = H;
        this.N = N;
    }
    
    public RecIntegral() 
    {
        A = 0;
        B = 0;
        H = 0;
    }
}